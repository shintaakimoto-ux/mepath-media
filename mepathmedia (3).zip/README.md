# Mepath|総合型選抜(AO入試)がわかるメディア

株式会社Mepathが運営する、高校生向けの総合型選抜(AO入試)情報メディアサイトです。
[Astro](https://astro.build) で作られた静的サイトで、記事はMarkdownファイルで管理します。

- **エンジニアでなくても、記事の追加は「ファイルを1つ作って push するだけ」です**
- スマホでの読みやすさを最優先にデザインしています

---

## 📝 記事を追加する方法(いちばん大事なところ)

### 1. 記事ファイルを作る

`src/content/articles/` フォルダの中に、新しい `.md` ファイルを作ります。

- ファイル名は **半角英数字とハイフン** にしてください(例: `mensetsu-fukusou.md`)
- ファイル名がそのまま記事のURLになります(例: `/articles/mensetsu-fukusou/`)

### 2. ファイルの中身を書く

ファイルの先頭に「記事の情報」、そのあとに本文を書きます。
既存の記事をコピーして書き換えるのがいちばん簡単です。

```markdown
---
title: 面接の服装、どうすればいい?
description: 制服? 私服? 総合型選抜の面接の服装のきほんを解説します。
category: 対策のヒント
order: 31
---

ここから本文です。ふつうの文章をそのまま書けばOK。

## 見出しはこう書く(半角シャープ2つ+半角スペース)

**太字にしたいところは、アスタリスク2つで囲みます。**

- 箇条書きは
- ハイフン+半角スペースで書けます
```

先頭の「記事の情報」のルール:

| 項目 | 説明 |
| --- | --- |
| `title` | 記事のタイトル |
| `description` | 記事の説明(トップページのカードに表示。60〜90字くらい) |
| `category` | 次の4つのどれか(コピペ推奨): `入試の基本` `最新の動き` `対策のヒント` `進学とお金` |
| `order` | 表示順の数字。**いま一番大きい数字+1にすると、トップの先頭(新着)に表示されます** |

### 3. push する(GitHubに反映する)

GitHubのWeb画面から直接ファイルを作る場合:

1. GitHubのリポジトリページで `src/content/articles` フォルダを開く
2. 「Add file」→「Create new file」をクリック
3. ファイル名と中身を入力して「Commit changes」

これだけで、**数分後に自動でサイトに反映されます**(Vercelが自動でビルド&公開してくれます)。

---

## 🔗 LINEのURL・アプリ情報を差し替える

`src/config.ts` を開いて、ここを書き換えてください。

```ts
export const LINE_URL = 'https://lin.ee/TCfLWiZn';  // 公式LINEのURL
export const AI_APP_NAME = 'ミーパス';               // 総合型選抜アプリの名前
export const AI_APP_RELEASE = '2026年9月リリース予定'; // リリース時期の表記
```

### CTA(ボタン)の導線について

- ヘッダーの「アプリ『ミーパス』」ボタンと、フッター手前のバンド → **ミーパスの紹介ページ(`/ai/`)** へ
- `/ai/` はリリース前の予告ページです(利用ボタンなし。「告知は公式LINEで届くよ」と案内)
- 紹介ページの文言・機能説明は `src/pages/ai.astro` で編集できます

## 🧭 記事末尾の「まずやること」ステップについて

すべての記事の最後に「じゃあ、まずなにをすればいい?」ボタンがあり、押すと4ステップ(①LINE登録 → ②情報に触れる → ③高1・高2はアプリで対策 → ④高3は6月ごろ塾を検討)が開いて、最後にミーパスのボタンが出ます。

- 文言の編集は `src/components/NextSteps.astro`
- 全記事に自動で入るので、記事側での作業は不要です

## 🌞 トップの「ミーちゃん診断」について

トップページでは、マスコットの「ミーちゃん」が学校タイプ・学年・理解度を質問し、回答に合わせて**おすすめ記事ランキングTOP5**を表示します。

- おすすめの点数ルールは `src/pages/index.astro` 内の `RECO` に書かれています(slugごとの加点表)
- 新しい記事を診断結果に出したいときは、`RECO` にその記事のslugと加点を1行足してください(足さなくてもエラーにはなりません)
- キャラクターの見た目は `src/components/Mascot.astro` で編集できます

## 🖼 ロゴ・画像を差し替える

- **ロゴ**: `public/logo.png`(設定済み。背景透過のPNG)。変えたいときは同じファイル名で上書きすれば、ヘッダー・フッターに反映されます
- **ファビコン**(ブラウザのタブのアイコン): `public/favicon.svg`(ロゴを再現したSVG)
- **OGP画像**(LINEやSNSでシェアされたときの画像): `public/ogp.png`(1200×630px)

---

## 💻 ローカルプレビュー(手元のパソコンで確認する方法)

[Node.js](https://nodejs.org/ja)(LTS版)をインストールしたうえで、ターミナルで:

```bash
# 1. 初回だけ:必要なものをインストール
npm install

# 2. プレビューを起動
npm run dev
```

表示された `http://localhost:4321` をブラウザで開くと、サイトが確認できます。
ファイルを保存すると自動で画面が更新されます。終了は `Ctrl + C` です。

---

## 🚀 Cloudflare Pagesへのデプロイ手順(初回のみ・約5分)

GitHubと連携して「push したら自動で公開」の状態を作ります。

1. [dash.cloudflare.com](https://dash.cloudflare.com) を開き、アカウントを作成(またはログイン)する
2. 左メニューの **「Workers & Pages」** → **「作成(Create)」** → **「Pages」タブ** → **「Gitに接続(Connect to Git)」** をクリック
3. **「GitHubを接続」** を押して認証し、このリポジトリ(`nextjs-boilerplate`)を選んで **「セットアップの開始(Begin setup)」**
4. ビルド設定を入力:
   - **プロジェクト名**: 好きな名前(例: `mepath-media`)。これが `https://mepath-media.pages.dev` のようなURLになります
   - **本番ブランチ(Production branch)**: `main`
   - **フレームワーク プリセット(Framework preset)**: `Astro` を選択
   - Build command / Build output は自動で `npm run build` / `dist` が入ります(そのままでOK)
5. **「保存してデプロイ(Save and Deploy)」** をクリック → 1〜2分で `https://◯◯◯.pages.dev` が発行されます

これ以降は、**GitHubの `main` に push するだけで自動で本番に反映されます**。
`main` 以外のブランチに push した場合も、プレビューURLが自動で発行されます(本番には影響しません)。

### 独自ドメインを使う場合(Cloudflare内で完結)

ドメインのDNSもCloudflareで管理している場合は、ワンクリックに近い手順です。

1. Pagesのプロジェクト画面 → **「カスタム ドメイン(Custom domains)」** タブ → **「カスタム ドメインを設定」**
2. 使いたいドメイン(例: `media.mepath.co.jp`)を入力 → 表示されるDNSレコードを確認して **「ドメインをアクティブ化」**(DNSがCloudflare管理なら自動で追加されます)
3. 数分でSSL証明書も自動発行され、`https://media.mepath.co.jp` で開けるようになります
4. 最後に `astro.config.mjs` の `site:` を本番URLに書き換えて push してください(SNSシェア用のURL生成に使われます)

> 参考: Vercelにデプロイする場合も手順はほぼ同じです([vercel.com](https://vercel.com) → Add New → Project → リポジトリをImport → Framework: Astro → Deploy)。ただしホスティングは1つに絞り、使わない側の連携は解除してください。

---

## 📁 フォルダ構成(ざっくり)

```
├── public/              # 画像・ファビコンなど(そのまま公開される)
├── src/
│   ├── config.ts        # ★ LINEのURL・サイト名などの設定
│   ├── content/
│   │   └── articles/    # ★ 記事のMarkdownファイル(ここに追加する)
│   ├── components/      # 部品(ヘッダー、記事カードなど)
│   ├── layouts/         # ページの共通レイアウト
│   ├── pages/           # ページ(トップ・記事・404)
│   └── styles/          # デザイン(色・フォントなど)
└── astro.config.mjs     # Astroの設定
```
