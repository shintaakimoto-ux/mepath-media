/**
 * サイト全体の設定ファイル
 *
 * ★ LINEのURLを差し替えるときは、下の LINE_URL の1行だけ書き換えてください。
 */

// 公式LINEのURL(プレースホルダ)。本番のURLに差し替えてください。
export const LINE_URL = 'https://lin.ee/TCfLWiZn';

// 総合型選抜対策AIアプリの情報(/ai/ ページやバンドの表記に使われます)
export const AI_APP_NAME = 'ミーパス';
export const AI_APP_RELEASE = '2026年9月リリース予定';

// サイト名・説明(検索結果やSNSシェアに表示されます)
export const SITE_NAME = 'Mepath';
export const SITE_TITLE = 'Mepath|総合型選抜(AO入試)がぜんぶわかるメディア';
export const SITE_DESCRIPTION =
  '総合型選抜(旧AO入試)をめざす高校生のための情報メディア。入試のきほんから、対策のヒント、進学とお金の話まで。株式会社Mepathがお届けします。';

// 運営会社
export const COMPANY_NAME = '株式会社Mepath';

// カテゴリ一覧(表示順もこの順になります)
export const CATEGORIES = [
  '入試の基本',
  '最新の動き',
  '対策のヒント',
  '進学とお金',
] as const;

export type Category = (typeof CATEGORIES)[number];
