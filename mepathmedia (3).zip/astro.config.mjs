// @ts-check
import { defineConfig } from 'astro/config';
import remarkCjkFriendly from 'remark-cjk-friendly';

// https://astro.build/config
export default defineConfig({
  // 独自ドメインを取得したら、ここを本番URLに変更してください
  site: 'https://mepath-ao.vercel.app',
  output: 'static',
  compressHTML: true,
  markdown: {
    // 日本語の文章内で **太字** が正しく効くようにするプラグイン
    remarkPlugins: [remarkCjkFriendly],
  },
});
